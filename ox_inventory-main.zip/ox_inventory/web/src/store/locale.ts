export const Locale: {
  [key: string]: string;
} = {};
